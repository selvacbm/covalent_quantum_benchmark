"""Paired cluster bootstrap conditional on saved OOF predictions; no model refitting.
Usage: python group_bootstrap.py BENCHMARK_ROOT OUTPUT_DIR
Requires numpy and pandas. Seed 20260922; 5000 replicates per validation/scope.
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
root,out=map(Path,sys.argv[1:]);out.mkdir(parents=True,exist_ok=True)
table=pd.read_csv(root/'data/processed/erbB_quantum_ai_table.csv').fillna('')
assert table.record_id.is_unique
meta=table.set_index('record_id'); results=[]; audit=[]
def metrics(c):
 tn,fp,fn,tp=np.moveaxis(c,-1,0)
 with np.errstate(divide='ignore',invalid='ignore'):
  ba=.5*(tp/(tp+fn)+tn/(tn+fp))
  den=np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  mcc=np.divide(tp*tn-fp*fn,den,out=np.zeros_like(den),where=den!=0)
 return np.stack([ba,mcc],axis=-1)
for validation in ['document','scaffold']:
 folder=root/f'results/erbB_{validation}_validation'
 pred=pd.read_csv(folder/'oof_predictions.csv')
 for scope in ['pooled','EGFR','ERBB2']:
  a=pred[(pred.scope==scope)&(pred.feature_set=='Morgan')].copy()
  b=pred[(pred.scope==scope)&(pred.feature_set=='Morgan_plus_quantum')].copy()
  keys=['seed','fold','record_id']; assert not a.duplicated(['seed','record_id']).any()
  paired=a.merge(b,on=keys,suffixes=('_a','_b'),validate='one_to_one')
  assert len(paired)==len(a)==len(b)
  assert (paired.y_true_a==paired.y_true_b).all()
  ids=sorted(paired.record_id.unique());seeds=sorted(paired.seed.unique())
  assert len(seeds)==30 and len(paired)==len(ids)*30
  m=meta.loc[ids]
  groups=(m.document_chembl_id.where(m.document_chembl_id!='', 'missing_doc__'+m.index.to_series()) if validation=='document' else m.murcko_scaffold.where(m.murcko_scaffold!='',m.canonical_smiles))
  names=sorted(groups.unique()); gi={v:i for i,v in enumerate(names)};si={v:i for i,v in enumerate(seeds)}
  counts=np.zeros((len(names),len(seeds),2,4))
  for row in paired.itertuples():
   g=gi[groups.loc[row.record_id]];s=si[row.seed]
   for j,p in enumerate([row.y_pred_a,row.y_pred_b]): counts[g,s,j,int(row.y_true_a)*2+int(p)]+=1
  # Check no test group is divided among folds within any repeat.
  chk=paired[['seed','fold','record_id']].copy();chk['group']=chk.record_id.map(groups)
  assert chk.groupby(['seed','group']).fold.nunique().max()==1
  point=np.diff(metrics(counts.sum(axis=0)),axis=1)[:,0,:].mean(axis=0)
  rng=np.random.default_rng(20260922); samples=[];rejected=0
  while sum(len(x) for x in samples)<5000:
   weights=rng.multinomial(len(names),np.full(len(names),1/len(names)),size=500)
   c=np.einsum('bg,gsjk->bsjk',weights,counts)
   v=np.diff(metrics(c),axis=2)[:,:,0,:].mean(axis=1)
   ok=np.isfinite(v).all(axis=1);rejected+=int((~ok).sum());samples.append(v[ok])
  dist=np.concatenate(samples)[:5000];lo,hi=np.percentile(dist,[2.5,97.5],axis=0)
  for k,metric in enumerate(['balanced_accuracy','mcc']):
   results.append(dict(validation=validation,scope=scope,n_records=len(ids),n_groups=len(names),n_repeats=30,bootstrap_draws=5000,seed=20260922,metric=metric,mean_delta=point[k],ci_low=lo[k],ci_high=hi[k],rejected_draws=rejected))
  audit.append(f'{validation}/{scope}: {len(ids)} records, {len(names)} groups, 30 complete repeats; model pairing, labels and group separation verified; rejected draws {rejected}.')
pd.DataFrame(results).to_csv(out/'cluster_bootstrap_summary.csv',index=False)
# Original repeat bootstrap reconstruction, preserving scope/metric RNG order.
for validation in ['document','scaffold']:
 f=root/f'results/erbB_{validation}_validation'
 p=pd.read_csv(f/'paired_quantum_increment.csv');old=pd.read_csv(f/'quantum_increment_summary.csv');rng=np.random.default_rng(20260723)
 for scope in sorted(p.scope.unique()):
  for metric in ['balanced_accuracy','mcc','roc_auc']:
   v=p[p.scope==scope].groupby('seed',sort=True)['delta_'+metric].mean().to_numpy()
   ci=np.percentile(rng.choice(v,(5000,len(v)),replace=True).mean(axis=1),[2.5,97.5])
   r=old[(old.scope==scope)&(old.metric=='delta_'+metric)].iloc[0]
   assert np.allclose([v.mean(),*ci],[r.mean_delta,r.bootstrap_ci_low,r.bootstrap_ci_high],atol=1e-12)
 audit.append(f'{validation}: all original repeat-bootstrap estimates and intervals reproduced to numerical precision.')
(out/'audit.txt').write_text('\n'.join(audit)+'\n')
print(pd.DataFrame(results).to_string(index=False));print('\n'.join(audit))
